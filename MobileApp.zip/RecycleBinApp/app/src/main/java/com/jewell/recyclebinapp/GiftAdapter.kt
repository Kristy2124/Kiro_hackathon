package com.jewell.recyclebinapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class GiftAdapter(
    private val gifts: List<Voucher>,
    private val onRedeemClick: (Voucher) -> Unit
) : RecyclerView.Adapter<GiftAdapter.GiftViewHolder>() {

    inner class GiftViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val giftImage: ImageView = itemView.findViewById(R.id.img_gift)
        val giftName: TextView = itemView.findViewById(R.id.tv_gift_name)
        val giftPoints: TextView = itemView.findViewById(R.id.tv_gift_points)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GiftViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_gift, parent, false)
        return GiftViewHolder(view)
    }

    override fun onBindViewHolder(holder: GiftViewHolder, position: Int) {
        val gift = gifts[position]
        holder.giftName.text = gift.name
        holder.giftPoints.text = "${gift.pointsRequired} pts"

        // placeholder gift icon, you can load different images if you want
        holder.giftImage.setImageResource(R.drawable.ic_grab)

        holder.itemView.setOnClickListener {
            onRedeemClick(gift)
        }
    }

    override fun getItemCount(): Int = gifts.size
}