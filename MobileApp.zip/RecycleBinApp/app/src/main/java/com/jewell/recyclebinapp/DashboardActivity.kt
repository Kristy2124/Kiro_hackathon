package com.jewell.recyclebinapp

import android.Manifest
import android.animation.Animator
import android.animation.ObjectAnimator
import android.app.Dialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import android.animation.AnimatorSet
import android.animation.ValueAnimator
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import android.util.Base64
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.ActivityResultLauncher
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import java.util.UUID
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


data class PointsReceived(
    val points: Double,
    val date: String
)

class SessionManager(private val context: Context) {

    private val PREF_NAME = "user_session"
    private val KEY_IS_LOGGED_IN = "isLoggedIn"
    private val KEY_USER_ID = "userId"
    private val KEY_RECENT_POINTS = "recentPoints"

    private val sessionPrefs: SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    private val userPrefs: SharedPreferences =
        context.getSharedPreferences("users", Context.MODE_PRIVATE)

    // -------------------------------
    // Session management
    // -------------------------------
    fun createLoginSession(userId: String) {
        sessionPrefs.edit().apply {
            putBoolean(KEY_IS_LOGGED_IN, true)
            putString(KEY_USER_ID, userId)
            apply()
        }
    }

    fun isLoggedIn(): Boolean = sessionPrefs.getBoolean(KEY_IS_LOGGED_IN, false)

    fun getUserId(): String? = sessionPrefs.getString(KEY_USER_ID, null)

    fun logout() {
        sessionPrefs.edit().clear().apply()
    }

    fun clearSession() {
        logout()
    }

    // -------------------------------
    // Points per user - CHANGED TO DOUBLE
    // -------------------------------
    fun updatePointsForUser(email: String, newPoints: Double) {
        userPrefs.edit().putFloat("${email}_points", newPoints.toFloat()).apply()
    }

    fun getPointsForUser(email: String): Double {
        return userPrefs.getFloat("${email}_points", 0f).toDouble()
    }

    // Convenience for current user - CHANGED TO DOUBLE
    fun updatePoints(newPoints: Double) {
        val user = UserRepository.currentUser ?: return
        user.points = newPoints
        updatePointsForUser(user.email, newPoints)
    }

    fun getPoints(): Double {
        val user = UserRepository.currentUser ?: return 0.0
        return getPointsForUser(user.email)
    }

    // -------------------------------
    // Recent points (for notifications)
    // -------------------------------
    fun setRecentPoints(points: Double) {
        sessionPrefs.edit().putFloat(KEY_RECENT_POINTS, points.toFloat()).apply()
    }

    fun getRecentPoints(): Double =
        sessionPrefs.getFloat(KEY_RECENT_POINTS, 0f).toDouble()

    fun clearRecentPoints() {
        sessionPrefs.edit().putFloat(KEY_RECENT_POINTS, 0f).apply()
    }

    // -------------------------------
    // Add recycling points - CHANGED TO DOUBLE
    // -------------------------------
    fun addRecyclingPoints(context: Context, pointsEarned: Double) {
        val user = UserRepository.currentUser ?: return
        val sessionManager = SessionManager(context)

        // Update user points
        user.points += pointsEarned // Update in-memory User object
        updatePoints(user.points) // Persist to SharedPreferences via updatePointsForUser
        setRecentPoints(pointsEarned)

        // Save to points received history
        val currentDate = java.text.SimpleDateFormat(
            "dd/MM/yyyy HH:mm", java.util.Locale.getDefault()
        ).format(java.util.Date())

        // Add to the shared repository
        UserRepository.pointsReceivedHistory.add(
            PointsReceived(pointsEarned, currentDate)
        )

        // Save the updated history
        savePointsHistory(context, user.email)

        // Toast.makeText(context, "You earned $pointsEarned points!", Toast.LENGTH_SHORT).show()
    }

    // -------------------------------
    // Helper to get current user with updated points
    // -------------------------------
    fun getCurrentUser(): User? {
        val user = UserRepository.currentUser ?: return null
        user.points = getPoints()
        return user
    }

    fun saveRedeemedVouchers(context: Context, email: String) {
        val prefs = context.getSharedPreferences("redeemed_vouchers", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        val gson = com.google.gson.Gson()
        val json = gson.toJson(UserRepository.redeemedVouchers)
        editor.putString("${email}_vouchers", json)
        editor.apply()
    }

    fun loadRedeemedVouchers(context: Context, email: String) {
        val prefs = context.getSharedPreferences("redeemed_vouchers", Context.MODE_PRIVATE)
        val gson = com.google.gson.Gson()
        val json = prefs.getString("${email}_vouchers", null)
        if (json != null) {
            val type = com.google.gson.reflect.TypeToken.getParameterized(
                MutableList::class.java, RedeemedVoucher::class.java
            ).type
            UserRepository.redeemedVouchers.clear()
            UserRepository.redeemedVouchers.addAll(gson.fromJson(json, type))
        } else {
            UserRepository.redeemedVouchers.clear()
        }
    }

    // Add these methods to save and load points history
    fun savePointsHistory(context: Context, email: String) {
        val prefs = context.getSharedPreferences("points_history", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        val gson = Gson()
        val json = gson.toJson(UserRepository.pointsReceivedHistory)
        editor.putString("${email}_points_history", json)
        editor.apply()

        // Debug logging
        Log.d("PointsHistory", "Saved ${UserRepository.pointsReceivedHistory.size} items for email: $email")
    }

    fun loadPointsHistory(context: Context, email: String) {
        val prefs = context.getSharedPreferences("points_history", Context.MODE_PRIVATE)
        val gson = Gson()
        val json = prefs.getString("${email}_points_history", null)

        // Add debug logging
        Log.d("PointsHistory", "Loading history for email: $email")
        Log.d("PointsHistory", "JSON found: ${json != null}")

        if (json != null) {
            val type = object : TypeToken<MutableList<PointsReceived>>() {}.type
            UserRepository.pointsReceivedHistory.clear()
            UserRepository.pointsReceivedHistory.addAll(gson.fromJson(json, type))

            // Debug log
            Log.d("PointsHistory", "Loaded ${UserRepository.pointsReceivedHistory.size} items")
        } else {
            UserRepository.pointsReceivedHistory.clear()
            Log.d("PointsHistory", "No history found, cleared list")
        }
    }


}

class PointsReceivedActivity : AppCompatActivity() {
    private lateinit var adapter: PointsReceivedAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification)

        val rvPoints: RecyclerView = findViewById(R.id.rv_notifications)
        val btnBack: ImageButton = findViewById(R.id.btn_back)
        val btnAccountDetails: ImageButton = findViewById(R.id.btn_account_details)
        val btnNotifications: ImageButton = findViewById(R.id.btn_notifications)
        val tvTitle: TextView = findViewById(R.id.tv_notification_title)
        val tvEmpty: TextView = findViewById(R.id.tv_empty)

        // Set the title
        tvTitle.text = "Points History"

        // Hide the notification button since we're already in the points screen
        btnNotifications.visibility = View.GONE

        rvPoints.layoutManager = LinearLayoutManager(this)

        adapter = PointsReceivedAdapter(UserRepository.pointsReceivedHistory)
        rvPoints.adapter = adapter

        // Check if list is empty
        checkIfEmpty()

        // Back button
        btnBack.setOnClickListener { finish() }

        // Account details button
        btnAccountDetails.setOnClickListener {
            startActivity(Intent(this, AccountDetailsActivity::class.java))
        }

        // Notification button is hidden, but just in case
        btnNotifications.setOnClickListener {
            Toast.makeText(this, "You're already in Points History", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        // Create a reversed copy of the history
        val reversedHistory = UserRepository.pointsReceivedHistory.asReversed()
        adapter.updateData(reversedHistory)
        checkIfEmpty()
    }

    private fun checkIfEmpty() {
        val rvPoints: RecyclerView = findViewById(R.id.rv_notifications)
        val tvEmpty: TextView = findViewById(R.id.tv_empty)

        if (UserRepository.pointsReceivedHistory.isEmpty()) {
            rvPoints.visibility = View.GONE
            tvEmpty.visibility = View.VISIBLE
        } else {
            rvPoints.visibility = View.VISIBLE
            tvEmpty.visibility = View.GONE
        }
    }
}

class PointsReceivedAdapter(private var items: List<PointsReceived>) :
    RecyclerView.Adapter<PointsReceivedAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_2, parent, false)
        return ViewHolder(view)
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvPoints: TextView = view.findViewById(android.R.id.text1)
        val tvDate: TextView = view.findViewById(android.R.id.text2)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        // CHANGED: Format points to 2 decimal places
        holder.tvPoints.text = "+${String.format("%.4f", item.points)} pts"
        holder.tvPoints.setTextColor(Color.parseColor("#4CAF50")) // green
        holder.tvDate.text = item.date
    }

    override fun getItemCount(): Int = items.size

    fun updateData(newItems: List<PointsReceived>) {
        items = newItems
        notifyDataSetChanged()
    }
}




data class RedeemedVoucher(
    val name: String,
    val pointsSpent: Double, // CHANGED TO DOUBLE
    val dateRedeemed: String, // store as a formatted string
    val imageResId: Int
)

// User.kt - CHANGED TO DOUBLE
data class User(
    val id: Int,
    val name: String,
    val email: String,
    var points: Double // CHANGED TO DOUBLE
)

// Voucher.kt - CHANGED TO DOUBLE
data class Voucher(
    val name: String,
    val pointsRequired: Double, // CHANGED TO DOUBLE
    val imageResId: Int
)

class RedeemedVouchersAdapter(
    private val redeemedList: List<RedeemedVoucher>
) : RecyclerView.Adapter<RedeemedVouchersAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imgVoucher: ImageView = view.findViewById(R.id.img_voucher)
        val tvName: TextView = view.findViewById(R.id.tv_voucher_name)
        val tvPoints: TextView = view.findViewById(R.id.tv_voucher_points)
        val tvDate: TextView = view.findViewById(R.id.tv_voucher_date)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_redeemed_voucher_card, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = redeemedList[position]

        // Display stored image
        holder.imgVoucher.setImageResource(item.imageResId)
        holder.tvName.text = item.name
        // ✅ Make marquee work
        holder.tvName.isSelected = true
        // CHANGED: Format points to 2 decimal places
        holder.tvPoints.text = "-${String.format("%.2f", item.pointsSpent)} pts"
        holder.tvDate.text = item.dateRedeemed
    }

    override fun getItemCount(): Int = redeemedList.size
}

class VouchersAdapter(
    private val vouchers: List<Voucher>,
    private val context: Context
) : RecyclerView.Adapter<VouchersAdapter.VoucherViewHolder>() {

    inner class VoucherViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imgGift: ImageView = itemView.findViewById(R.id.img_gift)
        val nameText: TextView = view.findViewById(R.id.tv_gift_name)
        val pointsText: TextView = view.findViewById(R.id.tv_gift_points)

        init {
            view.setOnClickListener {
                val voucher = vouchers[adapterPosition]
                // Show redeem dialog when item clicked
                val dialog = RedeemConfirmationDialog(context, voucher) { newPoints ->
                    // Update dashboard points
                    if (context is DashboardActivity) {
                        context.updatePoints(newPoints)
                    }
                }
                dialog.show()
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VoucherViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_gift, parent, false)
        return VoucherViewHolder(view)
    }

    override fun onBindViewHolder(holder: VoucherViewHolder, position: Int) {
        val voucher = vouchers[position]
        holder.nameText.text = voucher.name
        // CHANGED: Format points to 2 decimal places
        holder.pointsText.text = "${String.format("%.2f", voucher.pointsRequired)} pts"
        holder.imgGift.setImageResource(voucher.imageResId)
    }

    override fun getItemCount(): Int = vouchers.size
}


object UserRepository {
    var currentUser: User? = null

    val vouchers = listOf(
        // Eco-friendly products - CHANGED TO DOUBLE
        Voucher("Reusable Water Bottle", 300.00, R.drawable.ic_water_bottle),
        Voucher("Eco Tote Bag", 400.00, R.drawable.ic_tote_bag),
        Voucher("Bamboo Toothbrush Set", 350.00, R.drawable.ic_bamboo_toothbrush),

        // Discount vouchers
        Voucher("Lazada RM10 Off", 500.00, R.drawable.ic_lazada),
        Voucher("Shopee 20% Off", 550.00, R.drawable.ic_shopee),
        Voucher("Local Café Discount", 300.00, R.drawable.ic_cafe_discount),

        // Public transport credits
        Voucher("Touch 'n Go RM5 Reload", 300.00, R.drawable.ic_touchngo),
        Voucher("Grab Ride Credit RM10", 600.00, R.drawable.ic_grab),

        // Educational workshops
        Voucher("Eco Workshop Ticket", 700.00, R.drawable.ic_workshop),
        Voucher("Sustainability Webinar Pass", 500.00, R.drawable.ic_webinar),

        // Local business rewards
        Voucher("Local Bakery Free Pastry", 400.00, R.drawable.ic_bakery),
        Voucher("Local Bookstore RM10 Voucher", 0.05, R.drawable.ic_bookstore)
    )

    val redeemedVouchers = mutableListOf<RedeemedVoucher>() // new list
    val pointsReceivedHistory = mutableListOf<PointsReceived>()
}

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val emailEditText: EditText = findViewById(R.id.et_email)
        val passwordEditText: EditText = findViewById(R.id.et_password)
        val loginButton: Button = findViewById(R.id.btn_login)
        val registerButton: Button = findViewById(R.id.btn_go_register) // ✅ add this

        val sessionManager = SessionManager(this)
        if (sessionManager.isLoggedIn()) {
            // Go straight to Dashboard if session exists
            startActivity(Intent(this, DashboardActivity::class.java))
            finish() // finish LoginActivity only if session exists
        }

        // 🔹 Login button click
        loginButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            // 1️⃣ Email validation
            if (email.isEmpty()) {
                emailEditText.error = "Email is required"
                emailEditText.requestFocus()
                return@setOnClickListener
            }
            val emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"
            if (!email.matches(emailPattern.toRegex())) {
                emailEditText.error = "Invalid email address"
                emailEditText.requestFocus()
                return@setOnClickListener
            }

            // 2️⃣ Password validation
            if (password.isEmpty()) {
                passwordEditText.error = "Password is required"
                passwordEditText.requestFocus()
                return@setOnClickListener
            }

            // 3️⃣ Check SharedPreferences for saved user
            val prefs = getSharedPreferences("users", Context.MODE_PRIVATE)
            val savedPassword = prefs.getString(email, null)
            val userId = prefs.getString("${email}_id", null)

            if (savedPassword != null && savedPassword == password && userId != null) {
                // ✅ Start session
                val sessionManager = SessionManager(this)
                sessionManager.createLoginSession(userId)

                // Restore user info
                val name = prefs.getString("${email}_name", "User") ?: "User"
                val points = sessionManager.getPoints()
                UserRepository.currentUser = User(
                    id = userId.hashCode(),
                    name = name,
                    email = email,
                    points = points
                )

                // ✅ Load redeemed vouchers for this user
                sessionManager.loadRedeemedVouchers(this, email)

                sessionManager.loadPointsHistory(this, email)
                // ✅ Navigate to Dashboard
                startActivity(Intent(this, DashboardActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Invalid login credentials", Toast.LENGTH_SHORT).show()
            }
        }

        // 🔹 Register button click
        registerButton.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }

    }
}


class WelcomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_welcome)

        // Clear any existing session when entering the app
        val sessionManager = SessionManager(this)
        sessionManager.clearSession()
        UserRepository.currentUser = null

        val continueButton: Button = findViewById(R.id.btn_continue)
        continueButton.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            // Don't need finish() if you want back to Welcome
        }
    }
}




class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        setContentView(R.layout.activity_register)

        // 🔹 Connect XML fields with Kotlin variables
        val etName: EditText = findViewById(R.id.et_name)
        val etEmail: EditText = findViewById(R.id.et_email)
        val etPassword: EditText = findViewById(R.id.et_password)
        val registerButton: Button = findViewById(R.id.btn_register)
        val loginButton: Button = findViewById(R.id.btn_login)

        // Handle Register button click
        registerButton.setOnClickListener {
            val name = etName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            // ✅ Name validation
            if (name.isEmpty()) {
                etName.error = "Name is required"
                etName.requestFocus()
                return@setOnClickListener
            }

            if (name.length < 2) {
                etName.error = "Name too short"
                etName.requestFocus()
                return@setOnClickListener
            }

            // ✅ Email validation
            if (email.isEmpty()) {
                etEmail.error = "Email is required"
                etEmail.requestFocus()
                return@setOnClickListener
            }

            val emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"
            if (!email.matches(emailPattern.toRegex())) {
                etEmail.error = "Invalid email address"
                etEmail.requestFocus()
                return@setOnClickListener
            }

            // ✅ Password validation
            if (password.isEmpty()) {
                etPassword.error = "Password is required"
                etPassword.requestFocus()
                return@setOnClickListener
            }

            if (password.length < 6) {
                etPassword.error = "Password must be at least 6 characters"
                etPassword.requestFocus()
                return@setOnClickListener
            }

            // Optional: Add more password rules (uppercase, digit, etc.)
            val passwordPattern = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{6,}$"
            if (!password.matches(passwordPattern.toRegex())) {
                etPassword.error = "Password must contain letters and numbers"
                etPassword.requestFocus()
                return@setOnClickListener
            }

            // ✅ Save user if all validations pass
            val prefs = getSharedPreferences("users", Context.MODE_PRIVATE)

            // Check if email already exists
            if (prefs.contains(email)) {
                etEmail.error = "Email already registered"
                etEmail.requestFocus()
                Toast.makeText(this, "This email is already registered. Please login.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val editor = prefs.edit().apply {
                putString("${email}_name", name)
                putString("${email}_email", email)
                apply()
            }
            val userId = UUID.randomUUID().toString()
            editor.putString(email, password)
            editor.putString("${email}_id", userId)
            editor.apply()

            Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        // Handle Login button click
        loginButton.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }
    }
}

object RecyclingCategories {
    val categoryMultiplier = mapOf(
        "plastic" to 0.02,
        "metal" to 0.03,
        "glass" to 0.015,
        "paper" to 0.01,
        "organic" to 0.005,
        "unknown" to 0.0,
        "hazardous" to 0.0
    )
}



class DashboardActivity : AppCompatActivity() {

    lateinit var tvPoints: TextView

    // Use ActivityResultLauncher for getting results from CameraWebViewActivity
    private val getCategoryResultLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val category = result.data?.getStringExtra("category_result")
            val weightInGrams = result.data?.getDoubleExtra("weight_in_grams", 0.0) ?: 0.5
            if (category != null) {
                val sessionManager = SessionManager(this)
                val pointsEarned = calculatePoints(weightInGrams, category)
                sessionManager.addRecyclingPoints(this, pointsEarned) // This updates the User object and SharedPreferences
                Log.d("DashboardActivity", "Calculated points: $pointsEarned")

                // Update UI - THIS IS THE CRITICAL PART
                val latestPoints = sessionManager.getPoints() // Reads from SharedPreferences
                UserRepository.currentUser?.points = latestPoints // Updates the in-memory User object
                tvPoints.text = "Current Points: ${String.format("%.2f", latestPoints)}"

                Toast.makeText(this, "Recycled $category! Earned ${String.format( "%.4f", pointsEarned)} points!", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Analysis completed, but no category received.", Toast.LENGTH_SHORT).show()
            }
        } else if (result.resultCode == Activity.RESULT_CANCELED) {
            Toast.makeText(this, "Camera process cancelled.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        val sessionManager = SessionManager(this)
        if (!sessionManager.isLoggedIn()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        // Initialize views
        tvPoints = findViewById(R.id.tv_points)
        val tvGreeting = findViewById<TextView>(R.id.tv_greeting)
        val pastVouchers = findViewById<TextView>(R.id.btn_past_vouchers)
        pastVouchers.isSelected = true
        pastVouchers.requestFocus()

        val user = UserRepository.currentUser

        // CHANGED: Format points to 2 decimal places
        tvPoints.text = "Current Points: ${String.format("%.2f", user?.points ?: 0.0)}"
        tvGreeting.text = "Hi, ${user?.name ?: "User"}!"

        pastVouchers.setOnClickListener {
            startActivity(Intent(this, PastVouchersActivity::class.java))
        }

        val rvGifts = findViewById<RecyclerView>(R.id.rv_gifts)
        rvGifts.layoutManager = LinearLayoutManager(this)
        rvGifts.adapter = VouchersAdapter(UserRepository.vouchers, this)

        // Navigation buttons (back, notifications, dashboard, account details)
        findViewById<ImageButton>(R.id.btn_back)?.setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.btn_notifications)?.setOnClickListener {
            startActivity(Intent(this, NotificationActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            })
        }
        findViewById<ImageButton>(R.id.btn_dashboard)?.setOnClickListener {
            startActivity(Intent(this, DashboardActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            })
        }
        findViewById<ImageButton>(R.id.btn_account_details)?.setOnClickListener {
            startActivity(Intent(this, AccountDetailsActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            })
        }

        // Camera button logic
        val btnCamera = findViewById<ImageButton>(R.id.btn_camera)
        btnCamera.setOnClickListener {
            val builder = androidx.appcompat.app.AlertDialog.Builder(this)
            builder.setTitle("Open Camera Link")
            builder.setMessage("Do you want to open the external camera hackathon page for recycling?")
            builder.setPositiveButton("Yes") { dialog, _ ->
                // Instead of ACTION_VIEW, we now launch our custom WebView activity
                val intent = Intent(this, CameraWebViewActivity::class.java)
                getCategoryResultLauncher.launch(intent)
                dialog.dismiss()
            }
            builder.setNegativeButton("No") { dialog, _ ->
                dialog.dismiss()
            }
            builder.show()
        }
    }

    override fun onResume() {
        super.onResume()
        val sessionManager = SessionManager(this)
        val latestPoints = sessionManager.getPoints()
        tvPoints.text = "Current Points: ${String.format("%.2f", latestPoints)}"
        UserRepository.currentUser?.points = latestPoints
    }

    override fun onBackPressed() {
        SessionManager(this).clearSession()
        UserRepository.currentUser = null
        super.onBackPressed()
    }

    fun updatePoints(newPoints: Double) { // Change Int to Double
        tvPoints.text = "Current Points: ${String.format("%.2f", newPoints)}" // Already uses String.format for Double
        UserRepository.currentUser?.points = newPoints // Update the user object with the new double value
    }
    // Helper function to calculate points
    fun calculatePoints(weightInGrams: Double, category: String): Double {
        val multiplier = RecyclingCategories.categoryMultiplier[category.lowercase()] ?: 0.0
        Log.d("PointsCalc", "Category: $category, Multiplier: $multiplier, Weight: $weightInGrams")
        return weightInGrams * multiplier
    }
}

class CameraWebViewActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var cameraPhotoPath: String? = null

    // For requesting CAMERA permission at runtime - DECLARED AT CLASS LEVEL
    private val requestCameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            // Permission granted, now try to re-trigger the file chooser
            // This might require user to click the camera button on the web page again
            Toast.makeText(this, "Camera permission granted. Please try opening camera again on the web page.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Camera permission denied. Cannot access camera.", Toast.LENGTH_SHORT).show()
            filePathCallback?.onReceiveValue(null) // Cancel the file chooser
            filePathCallback = null
        }
    }

    // For handling the result of the camera intent (when WebChromeClient launches it) - DECLARED AT CLASS LEVEL
    private val fileChooserLauncher: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (filePathCallback == null) return@registerForActivityResult

            var results: Array<Uri>? = null

            // Check if there's a photo taken by the camera
            if (result.resultCode == Activity.RESULT_OK) {
                if (cameraPhotoPath != null) {
                    results = arrayOf(Uri.parse(cameraPhotoPath))
                } else if (result.data != null) {
                    // This handles cases where user picked from gallery or camera saved directly to data intent
                    if (result.data!!.data != null) {
                        results = arrayOf(result.data!!.data!!)
                    }
                }
            }

            filePathCallback?.onReceiveValue(results)
            filePathCallback = null
            cameraPhotoPath = null // Clear path after use
        }

    // This is the ONLY onCreate method for the activity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_webview_camera)

        webView = findViewById(R.id.webview_camera)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = false

        // 🌟 Ensure these two are set for fitting content
        webView.settings.useWideViewPort = true
        webView.settings.loadWithOverviewMode = true

        // 🌟 NEW: Set a Desktop User Agent String (already present, keep it)
        val desktopUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.88 Safari/537.36"
        webView.settings.userAgentString = desktopUserAgent

        // 🌟 OPTIONAL: Enable zoom controls for better navigation on a desktop site (already present, keep it)
        webView.settings.setSupportZoom(true)
        webView.settings.builtInZoomControls = true
        webView.settings.displayZoomControls = false

        // Crucial: Set a WebChromeClient to handle camera permissions and file choosers
        webView.webChromeClient = object : WebChromeClient() {

            // For handling <input type="file"> that requests camera
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@CameraWebViewActivity.filePathCallback = filePathCallback

                // Check if camera permission is needed and not granted
                if (ContextCompat.checkSelfPermission(
                        this@CameraWebViewActivity,
                        Manifest.permission.CAMERA
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    return true // Indicate we are handling the permission request
                }

                // Create intent to open camera
                var takePictureIntent: Intent? = null
                var photoFile: File? = null
                try {
                    photoFile = createImageFile()
                    takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    if (photoFile != null) {
                        cameraPhotoPath = "file:" + photoFile.absolutePath
                        // For simplicity, using Uri.fromFile for now, but FileProvider is recommended for API 24+
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photoFile))
                    } else {
                        takePictureIntent = null
                    }
                } catch (ex: IOException) {
                    Log.e("CameraWebViewActivity", "Unable to create Image File", ex)
                }

                // Create intent to pick images from gallery
                val contentSelectionIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }

                val intentArray: Array<Intent?> =
                    takePictureIntent?.let { arrayOf(it) } ?: arrayOfNulls(0)

                // Create a chooser intent to let user pick camera or gallery
                val chooserIntent = Intent(Intent.ACTION_CHOOSER).apply {
                    putExtra(Intent.EXTRA_INTENT, contentSelectionIntent)
                    putExtra(Intent.EXTRA_TITLE, "Image Chooser")
                    putExtra(Intent.EXTRA_INITIAL_INTENTS, intentArray)
                }

                fileChooserLauncher.launch(chooserIntent)
                return true
            }

            // For handling direct camera API requests (e.g., getUserMedia in JavaScript)
            override fun onPermissionRequest(request: PermissionRequest?) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    // Check if the request is for camera or microphone
                    if (request?.resources?.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) == true ||
                        request?.resources?.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) == true
                    ) {
                        // Check app's camera permission
                        if (ContextCompat.checkSelfPermission(
                                this@CameraWebViewActivity,
                                Manifest.permission.CAMERA
                            ) == PackageManager.PERMISSION_GRANTED
                        ) {
                            request.grant(request.resources) // Grant permission to WebView
                            Log.d("CameraWebViewActivity", "Granted WebView permission for camera.")
                        } else {
                            // Request runtime permission from user
                            request.deny()
                            Log.d("CameraWebViewActivity", "Denied WebView permission for camera (app permission not granted).")
                            requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA) // Request app permission
                        }
                    } else {
                        super.onPermissionRequest(request)
                    }
                } else {
                    super.onPermissionRequest(request)
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url.toString()
                Log.d("CameraWebViewActivity", "Loading URL: $url")

                if (url.startsWith("https://kristy2124.github.io/Kiro_hackathon/analysis.html")) {
                    view?.evaluateJavascript("localStorage.getItem('apiResult');") { result ->
                        Log.d("CameraWebViewActivity", "localStorage apiResult: $result") // This will show `\"metal\"`
                        if (result != null && result != "null" && result.isNotEmpty()) {
                            try {
                                // Original: val cleanResult = result.trim('"')
                                // New: More robust cleaning
                                val cleanedAndUnescapedResult = result.trim() // Remove outer spaces
                                    .replace("\\\"", "") // Remove escaped quotes \"
                                    .trim('"') // Remove any remaining quotes if they weren't escaped

                                val category = cleanedAndUnescapedResult // Use the fully cleaned string
                                Log.d("CameraWebViewActivity", "Extracted and Cleaned Category: '$category'") // Check with single quotes to see if there are extra spaces

                                if (category.isNotEmpty()) {
                                    val resultIntent = Intent().apply {
                                        putExtra("category_result", category)
                                        putExtra("weight_in_grams", 0.5)
                                    }
                                    setResult(Activity.RESULT_OK, resultIntent)
                                    finish()
                                } else {
                                    setResult(Activity.RESULT_CANCELED)
                                    finish()
                                }
                            } catch (e: Exception) {
                                Log.e("CameraWebViewActivity", "Error parsing localStorage result: ${e.message}", e)
                                setResult(Activity.RESULT_CANCELED)
                                finish()
                            }
                        } else {
                            Log.d("CameraWebViewActivity", "apiResult is null or empty in localStorage.")
                            setResult(Activity.RESULT_CANCELED)
                            finish()
                        }
                    }
                    return true
                }
                return super.shouldOverrideUrlLoading(view, request)
            }
        }
        webView.loadUrl("https://kristy2124.github.io/Kiro_hackathon/")
    }

    @Throws(IOException::class)
    private fun createImageFile(): File? {
        // Create an image file name
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val imageFileName = "JPEG_" + timeStamp + "_"
        val storageDir: File? = getExternalFilesDir(null) // Use app-specific storage for temporary files
        val image = File.createTempFile(
            imageFileName, /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        )
        return image
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            setResult(Activity.RESULT_CANCELED)
            super.onBackPressed()
        }
    }
}

class NotificationActivity : AppCompatActivity() {

    private lateinit var adapter: PointsReceivedAdapter
    private lateinit var rvPoints: RecyclerView
    private lateinit var tvEmpty: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification)



        rvPoints = findViewById(R.id.rv_notifications)
        tvEmpty = findViewById(R.id.tv_empty)
//        val btnBack: ImageButton = findViewById(R.id.btn_back)
//        val btnAccountDetails: ImageButton = findViewById(R.id.btn_account_details)

        rvPoints.layoutManager = LinearLayoutManager(this)
        adapter = PointsReceivedAdapter(emptyList())
        rvPoints.adapter = adapter

//        btnBack.setOnClickListener { finish() }
//        btnAccountDetails.setOnClickListener {
//            startActivity(Intent(this, AccountDetailsActivity::class.java))
//        }

        // Back button (optional: finish current activity)
        // Set click listeners for top bar buttons
        val btnBack = findViewById<ImageButton?>(R.id.btn_back)
        btnBack?.setOnClickListener { finish() }

        val btnNotifications = findViewById<ImageButton?>(R.id.btn_notifications)
        btnNotifications?.setOnClickListener {
            val intent = Intent(this, NotificationActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            startActivity(intent)
        }
        val btnDashboard = findViewById<ImageButton?>(R.id.btn_dashboard)
        btnDashboard?.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            startActivity(intent)
        }


        val btnAccountDetails = findViewById<ImageButton?>(R.id.btn_account_details)
        btnAccountDetails?.setOnClickListener {
            val intent = Intent(this, AccountDetailsActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            startActivity(intent)
        }

        loadPointsHistory()
    }

    private fun loadPointsHistory() {
        val sessionManager = SessionManager(this)
        val user = sessionManager.getCurrentUser() ?: return

        lifecycleScope.launch(Dispatchers.IO) {
            sessionManager.loadPointsHistory(this@NotificationActivity, user.email)

            val points = UserRepository.pointsReceivedHistory
            withContext(Dispatchers.Main) {
                val reversedPoints = UserRepository.pointsReceivedHistory.asReversed()
                adapter.updateData(reversedPoints) // you need to add updateData in adapter
                checkIfEmpty()
            }
        }
    }

    private fun checkIfEmpty() {
        if (UserRepository.pointsReceivedHistory.isEmpty()) {
            rvPoints.visibility = View.GONE
            tvEmpty.visibility = View.VISIBLE
        } else {
            rvPoints.visibility = View.VISIBLE
            tvEmpty.visibility = View.GONE
        }
    }
}




class RedeemConfirmationDialog(context: Context, private val voucher: Voucher, private val onPointsUpdated: ((Double) -> Unit)? = null) : Dialog(context) {

    init {
        // Make the dialog window background transparent
        window?.setBackgroundDrawable(ColorDrawable(android.graphics.Color.TRANSPARENT))

        setContentView(R.layout.dialog_redeem)

        val messageView = findViewById<TextView>(R.id.tv_redeem_message)
        messageView.text =
            "\uD83C\uDF1F Are you sure you want to redeem ${voucher.name} for ${String.format("%.2f", voucher.pointsRequired.toDouble())} pts?"

        // ✅ Make all text bold
        messageView.setTypeface(null, Typeface.BOLD)

        findViewById<Button>(R.id.btn_yes).setOnClickListener {
            val user = UserRepository.currentUser
            val sessionManager = SessionManager(context)

            if (user != null) {
                // always get latest points
                user.points = sessionManager.getPoints() // Always get latest points

                if (user.points >= voucher.pointsRequired) {
                    user.points -= voucher.pointsRequired
                    sessionManager.updatePoints(user.points)

                    val currentDate = java.text.SimpleDateFormat(
                        "dd/MM/yyyy HH:mm",
                        java.util.Locale.getDefault()
                    ).format(java.util.Date())

                    UserRepository.redeemedVouchers.add(
                        RedeemedVoucher(
                            name = voucher.name,
                            pointsSpent = voucher.pointsRequired,
                            dateRedeemed = currentDate,
                            imageResId = voucher.imageResId
                        )
                    )
                    sessionManager.saveRedeemedVouchers(context, user.email)

                    Toast.makeText(context, "Redeemed ${voucher.name}!", Toast.LENGTH_SHORT).show()
                    // Pass the actual Double value of user.points
                    onPointsUpdated?.invoke(user.points) // Changed from user.points.toInt() to user.points
                } else {
                    Toast.makeText(context, "Not enough points!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(context, "User not found!", Toast.LENGTH_SHORT).show()
            }
            dismiss()
        }
        findViewById<Button>(R.id.btn_no).setOnClickListener { dismiss() }
        findViewById<ImageButton>(R.id.btn_close).setOnClickListener { dismiss() }
    }
}


class PastVouchersActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_past_vouchers)

        val vouchersList: RecyclerView = findViewById(R.id.rv_vouchers)
        vouchersList.layoutManager = LinearLayoutManager(this)
        vouchersList.adapter = RedeemedVouchersAdapter(UserRepository.redeemedVouchers.asReversed())

        val btnBack = findViewById<ImageButton?>(R.id.btn_back)
        btnBack?.setOnClickListener { finish() }

        val btnNotifications = findViewById<ImageButton?>(R.id.btn_notifications)
        btnNotifications?.setOnClickListener {
            val intent = Intent(this, NotificationActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            startActivity(intent)
        }

        val btnDashboard = findViewById<ImageButton?>(R.id.btn_dashboard)
        btnDashboard?.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            startActivity(intent)
        }

        val btnAccountDetails = findViewById<ImageButton?>(R.id.btn_account_details)
        btnAccountDetails?.setOnClickListener {
            val intent = Intent(this, AccountDetailsActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            startActivity(intent)
        }
    }
}


class AccountDetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account_details)

        val user = UserRepository.currentUser ?: return

        findViewById<TextView>(R.id.tv_member_id).text = "Member ID: ${user.id}"
        findViewById<TextView>(R.id.tv_member_name).text = "Name: ${user.name}"
        findViewById<TextView>(R.id.tv_member_email).text = "Email: ${user.email}"

        findViewById<Button>(R.id.btn_logout).setOnClickListener {
            SessionManager(this).clearSession()
            UserRepository.currentUser = null
            finishAffinity()
            startActivity(Intent(this, WelcomeActivity::class.java))
        }

        val btnBack = findViewById<ImageButton?>(R.id.btn_back)
        btnBack?.setOnClickListener { finish() }

        val btnNotifications = findViewById<ImageButton?>(R.id.btn_notifications)
        btnNotifications?.setOnClickListener {
            val intent = Intent(this, NotificationActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            startActivity(intent)
        }

        val btnDashboard = findViewById<ImageButton?>(R.id.btn_dashboard)
        btnDashboard?.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            startActivity(intent)
        }

        val btnAccountDetails = findViewById<ImageButton?>(R.id.btn_account_details)
        btnAccountDetails?.setOnClickListener {
            val intent = Intent(this, AccountDetailsActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            startActivity(intent)
        }

    }
}