<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="manifest" href="manifest.json">
    <button id="installBtn" style="display:none;">Install App</button>
    <title>Start Page</title>
    <style>
        body,html{
            height: 100%;
            margin:0;
            background-color: #F0F4F3;
            display: flex;
            justify-content: center; /*horizontal center */
            align-items: center; /*vertical center*/
            flex-direction: column; /*stack children vertically*/
        }
        img {
            max-width: 600px;
            height: auto;
            margin-bottom: 20px;
            
        }
        .start_button{
            background: none;/*removes the default button background color*/
            border: none; /*removes the default border from the button*/
        }
    </style>
</head>
<body>
    <!-- median position-->
    <img src = "images/front_image.png">
    <button class = "start_button" onclick="goToSecondPage()">
        <img src = "images/start_button.png">
    </button>
    <script src="functionality.js"></script>
</body>
</html>